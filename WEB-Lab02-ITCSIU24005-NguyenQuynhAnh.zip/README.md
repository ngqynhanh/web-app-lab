# Lab 02 CSS and Layout
Nguyen Quynh Anh - ITCSIU24005

Extract this archive and open ex01/index.html, ex02/index.html or ex03/index.html in a browser. The sites use local assets, external CSS and semantic HTML. No framework, JavaScript or installation is needed.

## Exercise 1
Department site with responsive navigation, active-page highlighting, faculty cards and accessible contrast. The report includes actual DevTools screenshots of the box model and a crossed-out navigation color declaration. The full screenshots are in report/evidence.

## Exercise 2
- Home page: hero with featured CS101 course, two call-to-action links and four statistics.
- Stats Grid: one column below 768px, two from 768px and four from 1024px.
- Catalog: keyword search and credit/availability controls, ten courses, sorting appearance, numeric alignment, zebra striping, hover and a sticky header inside the scrolling table.
- Registration: grouped fields, two-column student details on wider screens, visible focus, required indicators, .error feedback example and disabled controls. The full CS450 course cannot be selected.
- Confirmation: success styling and a clearly labeled illustrative summary.
- Loading-state styling is available through the catalog's preview disclosure.

The search and registration forms demonstrate GET submission. CSS does not implement text search, sorting, persistence or query-string parsing. The search page explains that the displayed records remain static; the confirmation summary is explicitly an example. Native validation is active for the real registration inputs. Separate labeled examples demonstrate custom error, disabled and success states.

## Exercise 3
The six original research pages have Professional Blue, Academic Green and Dark themes; publication sidebar/results Grid; CSS-only expandable rows; responsive project cards; Flexbox people cards; conditional form fields; a visual progress indicator; file-control styling; a static counter preview; and print/reduced-motion/contrast styles.

Open ex03/components.html, components-green.html and components-dark.html to compare the component library. Set the body data-theme attribute to default, green or dark to theme any page. Theme choices are manual. The performance.html table contains 60 labeled duplicate test rows, not 60 distinct publications.

## Report and measured evidence
The consolidated DOCX and PDF are in report.
- Page 2: actual DevTools box-model and overridden-rule screenshots.
- Page 7: measured Exercise 3 Performance audit table.
- report/evidence/ex3-performance-measurements.json: raw metrics and scope.
- report/evidence/ex3-scroll-trace.json: import into the DevTools Performance panel.
- report/evidence/verification.json: browser verification summary.

Fresh audit: 173 CSS style rules; 185 CSSOM entries including grouping rules and keyframes; 17,592 stylesheet bytes; five matched rules on the sampled table cell; 60 test rows; 119 recorded frame intervals with median 16.7ms and 95th percentile 16.8ms. Coverage is scoped to one page reload and scroll exercise; source characters outside used ranges are not proof of globally unused rules.

All 20 HTML pages passed at 320, 375, 768, 1024 and 1440px, for 100 checks. Tests also verified the stats layout, ten catalog records, sticky course header, disabled full course, custom error border, GET registration, three research themes, CSS expansion and conditional fields. External publication links were retained from the supplied Lab 1 source. Firefox and screen-reader validation remain manual follow-up checks.

## Teacher feedback addressed
| Feedback | Evidence |
| --- | --- |
| No hero | ex02/index.html featured-course hero |
| No stats grid | .stats-grid with 1/2/4 responsive columns |
| No search form | ex02/courses.html keyword and filter controls |
| Only eight courses | Ten catalog records and ten matching registration choices |
| No sticky header | .course-table thead th with sticky positioning; browser scroll check passed |
| No error or disabled styling | .error, .field-error and :disabled styles, visible examples and a disabled full course |
| Missing overridden-rule screenshot | Report page 2 and full screenshot in report/evidence |
| No measured Performance Audit numbers | Report page 7, raw measurements and timeline trace |
